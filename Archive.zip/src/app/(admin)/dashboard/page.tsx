import React from "react";

const DashboardPage = () => {
  return (
    <div>
      <h1 className="text-foreground"> Dashboard</h1>
    </div>
  );
};

export default DashboardPage;
